-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2018 at 08:23 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbuser`
--

-- --------------------------------------------------------

--
-- Table structure for table `datamasuk`
--

CREATE TABLE IF NOT EXISTS `datamasuk` (
`id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  `user_verif` int(1) NOT NULL,
  `kode_verif` int(4) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `datamasuk`
--

INSERT INTO `datamasuk` (`id`, `nama`, `username`, `email`, `password`, `user_verif`, `kode_verif`) VALUES
(4, 'hi', 'hihi', 'hihi@gmail.com', '1234', 1, 0),
(5, 'sisi', 'sisibudi', 'sisi@gmail.com', '12345', 1, 0),
(11, 'wewe', 'wewewa', 'we@gmail.com', '12', 1, 0),
(13, '', 'hhhh', 'hhhh', 'hhhh', 1, 0),
(20, 'sisi', 'sisisisi', 'japoh@gmail.com', 'utamiwijaya', 1, 0),
(30, 'tami', 'utami', 'utamiwijaya49@gmail.com', '11111111', 0, 1541),
(31, 'li', 'lilu', 'lilu@gmail.com', '1234', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `datamasuk`
--
ALTER TABLE `datamasuk`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `datamasuk`
--
ALTER TABLE `datamasuk`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=32;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
